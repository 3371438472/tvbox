<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
require_once 'Core/Start.php';
?>